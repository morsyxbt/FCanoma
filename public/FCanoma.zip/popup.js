// popup.js - Handles UI and user input for FC - anoma Auto Clicker

document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const intervalInput = document.getElementById('interval');
  const eventTypeSelect = document.getElementById('eventType');

  // Ask to pick multiple locations before starting
  startBtn.addEventListener('click', () => {
    alert('You will be prompted to pick 5 locations for auto tapping.');
    chrome.runtime.sendMessage({ action: 'pick-location', interval: parseFloat(intervalInput.value), eventType: eventTypeSelect.value });
  });

  // Send stop command to background
  stopBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'stop' });
  });
});
