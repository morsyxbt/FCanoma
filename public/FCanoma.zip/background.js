// background.js - Handles script injection and popup commands only

chrome.runtime.onInstalled.addListener(() => {
  // Nothing needed for now
});

function injectContentScript(tabId, callback) {
  chrome.scripting.executeScript({
    target: { tabId },
    files: ['content.js']
  }, () => {
    if (callback) callback();
  });
}

// Listen to popup messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'start' || msg.action === 'stop' || msg.action === 'pick-location') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        injectContentScript(tabs[0].id, () => {
          chrome.tabs.sendMessage(tabs[0].id, msg);
        });
      }
    });
  }
});
