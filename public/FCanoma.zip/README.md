# FC - anoma Auto Clicker Extension

A simple Chrome extension that auto-clicks at a user-defined interval. Inspired by IO Auto Clicker.

## Features
- Start/Stop hotkeys
- Interval control
- Click event type selection
- Popup UI
- Footer with Twitter link: [@morsyxbt](https://x.com/morsyxbt)

## Usage
1. Load the extension in Chrome (Developer Mode > Load unpacked > select this folder).
2. Open the popup to configure and start/stop auto clicking.
3. Click the Twitter link at the bottom to visit the developer's page.

## To Do
- Implement popup controls
- Add auto-clicking logic
- Polish UI and add icons

---
Built by [@morsyxbt](https://x.com/morsyxbt)
