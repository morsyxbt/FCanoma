// content.js - Handles auto click logic injected into the page
let clickIntervalId = null;
let clickLocations = [];
const MIN_LOCATIONS = 4;
const MAX_LOCATIONS = 5;

function startAutoClicker(interval, eventType) {
  if (clickIntervalId || clickLocations.length === 0) return;
  clickIntervalId = setInterval(() => {
    const idx = Math.floor(Math.random() * clickLocations.length);
    const { x, y } = clickLocations[idx];
    const event = new MouseEvent(eventType, {
      bubbles: true,
      cancelable: true,
      view: window
    });
    const elem = document.elementFromPoint(x, y);
    elem?.dispatchEvent(event);
  }, interval * 1000);
}

function stopAutoClicker() {
  if (clickIntervalId) {
    clearInterval(clickIntervalId);
    clickIntervalId = null;
  }
}

function showPickLocationOverlay(interval, eventType) {
  clickLocations = [];
  let picksNeeded = MAX_LOCATIONS;
  let pickCount = 0;
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = 0;
  overlay.style.left = 0;
  overlay.style.width = '100vw';
  overlay.style.height = '100vh';
  overlay.style.background = 'rgba(0,0,0,0.15)';
  overlay.style.zIndex = 999999;
  overlay.style.cursor = 'crosshair';
  const msgBox = document.createElement('div');
  msgBox.style.position = 'absolute';
  msgBox.style.top = '10px';
  msgBox.style.left = '50%';
  msgBox.style.transform = 'translateX(-50%)';
  msgBox.style.color = '#fff';
  msgBox.style.fontSize = '18px';
  msgBox.style.fontWeight = 'bold';
  msgBox.style.textShadow = '0 1px 4px #000';
  msgBox.innerText = `Click to pick location ${pickCount + 1} of ${picksNeeded}`;
  overlay.appendChild(msgBox);

  function pickHandler(e) {
    clickLocations.push({ x: e.clientX, y: e.clientY });
    pickCount++;
    if (pickCount < picksNeeded) {
      msgBox.innerText = `Click to pick location ${pickCount + 1} of ${picksNeeded}`;
    } else {
      document.body.removeChild(overlay);
      window.removeEventListener('click', pickHandler, true);
      startAutoClicker(interval, eventType);
    }
    e.preventDefault();
    e.stopPropagation();
  }

  window.addEventListener('click', pickHandler, true);
  document.body.appendChild(overlay);
}

if (!window.__FC_ANOMA_LISTENER__) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'pick-location') {
      stopAutoClicker();
      showPickLocationOverlay(msg.interval, msg.eventType);
    } else if (msg.action === 'start') {
      startAutoClicker(msg.interval, msg.eventType);
    } else if (msg.action === 'stop') {
      stopAutoClicker();
    }
  });
  window.__FC_ANOMA_LISTENER__ = true;
}
