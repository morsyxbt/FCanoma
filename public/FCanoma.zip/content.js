// content.js - Handles auto click logic injected into the page
let clickIntervalId = null;
let clickX = null, clickY = null;

function startAutoClicker(interval, eventType) {
  if (clickIntervalId) return;
  clickIntervalId = setInterval(() => {
    const event = new MouseEvent(eventType, {
      bubbles: true,
      cancelable: true,
      view: window
    });
    let elem, x, y;
    if (clickX !== null && clickY !== null) {
      x = clickX;
      y = clickY;
    } else {
      x = window.innerWidth / 2;
      y = window.innerHeight / 2;
    }
    elem = document.elementFromPoint(x, y);
    elem?.dispatchEvent(event);
  }, interval * 1000);
}

function stopAutoClicker() {
  if (clickIntervalId) {
    clearInterval(clickIntervalId);
    clickIntervalId = null;
  }
}

function showPickLocationOverlay(interval, eventType) {
  // Create overlay
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = 0;
  overlay.style.left = 0;
  overlay.style.width = '100vw';
  overlay.style.height = '100vh';
  overlay.style.background = 'rgba(0,0,0,0.15)';
  overlay.style.zIndex = 999999;
  overlay.style.cursor = 'crosshair';
  overlay.innerHTML = '<div style="position:absolute;top:10px;left:50%;transform:translateX(-50%);color:#fff;font-size:18px;font-weight:bold;text-shadow:0 1px 4px #000;">Click anywhere to pick location for auto clicks</div>';

  function pickHandler(e) {
    clickX = e.clientX;
    clickY = e.clientY;
    document.body.removeChild(overlay);
    window.removeEventListener('click', pickHandler, true);
    startAutoClicker(interval, eventType);
    e.preventDefault();
    e.stopPropagation();
  }

  window.addEventListener('click', pickHandler, true);
  document.body.appendChild(overlay);
}

if (!window.__FC_ANOMA_LISTENER__) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'pick-location') {
      stopAutoClicker();
      showPickLocationOverlay(msg.interval, msg.eventType);
    } else if (msg.action === 'start') {
      startAutoClicker(msg.interval, msg.eventType);
    } else if (msg.action === 'stop') {
      stopAutoClicker();
    }
  });
  window.__FC_ANOMA_LISTENER__ = true;
}
